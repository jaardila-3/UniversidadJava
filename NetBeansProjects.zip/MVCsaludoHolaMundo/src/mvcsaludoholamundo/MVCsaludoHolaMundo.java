/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvcsaludoholamundo;

import controlador.Controlador;
import modelo.Modelo;
import vista.Vista;

/**
 *
 * @author JORGE.ARDILAR
 */
public class MVCsaludoHolaMundo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Modelo model = new Modelo();
        Vista view = new Vista();
        Controlador ctrl = new Controlador(view, model);
        ctrl.iniciar();
    }
    
}
