/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import modelo.Modelo;
import vista.Vista;

/**
 *
 * @author JORGE.ARDILAR
 */
public class Controlador implements ActionListener{
    Modelo model = new Modelo();
    Vista view = new Vista();
    
    public Controlador(Vista view, Modelo model){
        this.view = view;
        this.model = model;
        this.view.btnSaludar.addActionListener(this);
    }
    
    public void iniciar(){
        view.setTitle("MVC Multiplicar");
        view.setLocationRelativeTo(null);
        view.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        view.setResizable(false);
        view.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e){
        view.txtSaludo.setText(model.saludar());
    }
    
}
